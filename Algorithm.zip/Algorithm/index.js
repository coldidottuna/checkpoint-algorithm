function analyser(sentence) {
  let charNumber = a.length;
  let words = 1;
  let vowels = 0;

  let x = sentence.toString();

  for (var i = 0; i < charNumber; i++) {
    if (
      x.charAt(i) == "a" ||
      x.charAt(i) == "e" ||
      x.charAt(i) == "i" ||
      x.charAt(i) == "o" ||
      x.charAt(i) == "u" ||
      x.charAt(i) == "y"
    ) {
      vowels++;
    }
    if (x.charAt(i) == "") {
      words++;
    }
  }
  return {
    voyelles: vowels,
    mot: words,
    total: charNumber,
  };
}
